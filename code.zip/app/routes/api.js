var User = require('../models/user');
var Benefit = require('../models/benefit');
var jwt = require('jsonwebtoken');
var secret = 'rogerfederer';
var AWS = require('aws-sdk');
var lexruntime = new AWS.LexRuntime();
var config = require('../../config');

module.exports = function (router) {
    //Route to http://localhost:8080/api/users, used to register a user
    //changed to suit dynamoose

    router.post('/users', (req, res) => {
        console.log("new user called");
        var user = new User();
        user.firstname = req.body.firstname;
        user.lastname = req.body.lastname;
        user.email = req.body.email;
        user.password = req.body.password;
        user.claims = [];
        if (user.firstname == null || user.lastname == '' || user.email == null || user.email == '') {
            res.json({
                success: false,
                message: 'Ensure that all fields have been provided'
            });
        } else {
            user.save(function (err) {
                if (err) {
                    res.json({
                        success: false,
                        message: err
                    });
                } else {
                    console.log("should work");
                    res.json({
                        success: true,
                        message: "Successfully created user" + user.firstname + user.email
                    });
                }
            });
        }
    });


    //Route to http://localhost:8080/api/benefits, used to add a benefit
    //changed to suit dynamoose
    router.post('/benefits', (req, res) => {
        var benefit = new Benefit();
        benefit.benefit = req.body.benefit;
        benefit.limit = parseInt(req.body.limit, 10);
        benefit.coverage = parseInt(req.body.coverage, 10);
        benefit.term = req.body.term;
        benefit.start = new Date(req.body.start);
        benefit.end = new Date(req.body.end);
        benefit.benefittype = req.body.benefittype;

        console.log(benefit.benefit);
        console.log(benefit.limit);
        console.log(benefit.coverage);
        console.log(benefit.term);
        console.log(benefit.start);
        console.log(benefit.end);
        console.log(benefit.benefittype);

        if (benefit.benefit == null || benefit.benefit == '' || benefit.limit == null || benefit.limit == '' || benefit.coverage == null || benefit.coverage == '' || benefit.term == null || benefit.term == '' || benefit.start == null || benefit.start == '' || benefit.end == null || benefit.end == '' || benefit.benefittype == null || benefit.benefittype == '') {
            res.json({
                success: false,
                message: 'Ensure that all fields have been provided'
            });
        } else {
            benefit.save(function (err) {
                if (err) {
                    res.json({
                        success: false,
                        message: err
                    });
                } else {
                    res.json({
                        success: true,
                        message: "Successfully created benefit"
                    });
                }
            });
        }
    });

    //Route to http://localhost:8080/api/addclaim, used to add claim to a user account(specified by user id)
    //changed to suit dynamoose
    router.post('/addclaim', (req, res) => {
        console.log(req.body);
        if (req.body.benefit == null || req.body.benefit == '' || req.body.email == null || req.body.email == '' || req.body.provider == null || req.body.provider == '' || req.body.date == null || req.body.date == '' || req.body.amount == null || req.body.amount == '') {
            res.json({
                success: false,
                message: 'Ensure that all fields have been filled'
            });
        } else {
            User.get({
                email: req.body.email
            }, function (err, result) {
                if (err) {
                    console.log('route error should follow');
                    console.log(err);
                    res.json({
                        success: false,
                        message: err
                    });
                } else {
                    if (result == null || result == '') {
                        res.json({
                            success: false,
                            message: "Could not find user"
                        });
                    } else {
                        var date = new Date(req.body.date);
                        var provider = req.body.provider;
                        var amount = req.body.amount;
                        console.log(typeof (req.body.amount));
                        if (typeof (req.body.amount) == 'string')
                            amount = parseInt(req.body.amount, 10);
                        var benefit = req.body.benefit;
                        result.addClaim(benefit, date, amount, provider, function (err) {
                            if (err) {
                                res.json({
                                    success: false,
                                    message: err
                                });
                            } else {
                                res.json({
                                    success: true,
                                    message: 'Successfully claimed benefit'
                                });
                            }
                        });
                    }
                }
            });
        }

    });

    //changed to suit dynamoose
    router.get('/getclaims', (req, res) => {
        console.log(req.query);
        User.get({
            email: req.query.email
        }, function (err, result) {
            if (err) {
                res.json({
                    success: false,
                    message: err
                });
            } else {
                if (result == null || result == '') {
                    res.json({
                        success: false,
                        message: 'No such user found'
                    });
                } else {
                    res.json({
                        success: true,
                        message: result.getClaims()
                    });
                }
            }
        })
    });

    //changed to suit dynamoose
    router.get('/getbenefittypes', (req, res) => {
        // res.header('Access-Control-Allow-Methods', 'DELETE, GET, HEAD, OPTIONS, PATCH, POST, PUT');
        // res.header("Access-Control-Allow-Origin", "*");
        // res.headers('Access-Control-Allow-Headers', 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token');
        res.json({
            benTypes: ["Vision", "Mental", "Physical", "Dental"]
        });
    });

    //changed to suit dynamoose
    router.get('/getbenefitsbytype', (req, res) => {
        Benefit.scan({
            benefittype: {
                eq: req.query.bentype
            }
        }, function (err, result) {
            if (err) {
                res.json({
                    success: false,
                    message: err
                });
            } else {
                if (result == null || result == '') {
                    res.json({
                        success: false,
                        message: 'No benefits found'
                    });
                } else {
                    res.json({
                        success: true,
                        message: result
                    });
                }
            }
        });
    });

    //changed to suit dynamoose
    router.get('/showallbenefits', (req, res) => {
        Benefit.scan().exec(function (err, result) {
            if (err) {
                res.send(err);
            } else {
                if (result.length == 0) {
                    res.send('No benefits created yet');
                } else {
                    res.send(result);
                }
            }
        })
    });

    //changed to suit dynamoose
    router.post('/authenticate', function (req, res) {
        debugger;
        console.dir(req.body.email);
        var uname = req.body.email; //"jack@amazon.com";
        User.get({
            email: uname
        }, function (err, user) {
            if (err) throw err;
            console.dir(user);
            console.dir("Printing user = " + user.firstname);
            console.dir("Printing user = " + user.lastname);
            console.dir("Printing user = " + user.password);

            if (!user) {
                res.json({
                    success: false,
                    message: 'Could not authenticate user'
                });
            } else {
                if (req.body.password) {
                    //var validPassword = user.comparePassword(req.body.password);
                    var validPassword = user.password == req.body.password;
                    if (!validPassword) {
                        res.json({
                            success: false,
                            message: 'Could not authenticate password'
                        });
                    } else {
                        var token = jwt.sign({
                            email: user.email,
                            firstname: user.firstname,
                            lastname: user.lastname
                        }, secret, {
                            expiresIn: '24h'
                        });
                        res.json({
                            success: true,
                            message: 'User authenticated',
                            token: token
                        });
                    }
                } else {
                    res.json({
                        success: false,
                        message: 'No password provided'
                    });
                }
            }
        });
    });

    router.use(function (req, res, next) {
        var token = req.body['X-Amz-Security-Token'] || req.body.query || req.headers['X-Amz-Security-Token'];
        next();
        return 0;
        if (token) {
            jwt.verify(token, secret, function (err, decoded) {
                if (err) {
                    res.json({
                        success: false,
                        message: "Token invalid"
                    });
                } else {
                    req.decoded = decoded;
                    next();
                }
            });
        } else {
            res.json({
                success: false,
                message: "No token provided"
            });
        }
    });

    router.post('/me', function (req, res) {
        console.log(req.decoded);
        res.send(req.decoded);
    });

    router.post('/sendtobot', function (req, res) {
        var params = {
            botAlias: '$LATEST',
            /* required */
            botName: config.botName || 'insuranceSAM',
            /* required */
            inputText: req.body.inputText,
            /* required */
            userId: 'sampleid',
            /* required */
            sessionAttributes: req.body.sessionAttributes || {}
        };
        lexruntime.postText(params, function (err, data) {
            if (err) {
                console.log(err, err.stack);
                res.json({
                    message: "Error"
                });
            } // an error occurred
            else {
                console.log(data);
                res.json(data);
            } // successful response
        });
    });
    return router;
}
