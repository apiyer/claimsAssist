var dynamoose = require('dynamoose');
var Schema = dynamoose.Schema;
var config = require('../../config');

var BenefitSchema = new Schema({
    benefit: {
        type: String,
        required: true,
        unique: true,
        hashKey: true
    },
    limit: {
        type: Number,
        required: true
    },
    coverage: {
        type: Number,
        min: 0,
        max: 100,
        required: true
    },
    term: {
        type: String,
        required: true
    },
    benefittype: {
        type: String,
        enum: ['Vision', 'Dental', 'Mental', 'Physical'],
        default: 'Vision'
    },
    start: {
        type: Date
    },
    end: {
        type: Date
    }
});

module.exports = dynamoose.model(config.benefitTable, BenefitSchema)
