var dynamoose = require('dynamoose');
var Schema = dynamoose.Schema;
var Benefit = require('./benefit');
var config = require('../../config');

var UserSchema = new Schema({
    firstname: {
        type: String,
        required: true
    },
    lastname: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: false
    },
    email: {
        type: String,
        required: true,
        lowercase: true,
        unique: true,
        hashKey: true
    },
    claims: {
        type: "list",
        list: [{
                benefit: {
                    type: String,
                    required: true
                },
                date: {
                    type: Date
                },
                amount: {
                    type: Number,
                    required: true
                },
                provider: {
                    type: String,
                    required: true
                }
    }
    ]
    }
}, {
    useDocumentTypes: true
});


//Add claim to user's account
UserSchema.methods.addClaim = function (benefit, date, amount, provider, cb) {
    var myClaim = {
        benefit: benefit,
        date: date,
        amount: amount,
        provider: provider
    };
    this.claims[this.claims.length] = myClaim;
    this.save(cb);
};

//Return log of all the claims made by user
UserSchema.methods.getClaims = function () {
    return this.claims;
}

var currentUser = dynamoose.model(config.userTable, UserSchema)

module.exports = currentUser;
