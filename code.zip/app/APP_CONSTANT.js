var APP_CONSTANT = {};
//This is the user pool id which will come from aws cognito user pool
APP_CONSTANT.USER_POOL_ID = 'us-east-1_7q4NtnqUp';
//This is the application client id which will come from aws cognito user pool
APP_CONSTANT.CLIENT_ID = '468h6prlt93vsgd1372958b27i';
//This is the user pool id which will come from aws cognito -> Manage federated identity -> Edit -> identity pool Id
APP_CONSTANT.IDENTITY_POOL_ID = 'us-east-1:564379e3-3bed-43fb-9c0a-297d6e18142d';
exports.APP_CONSTANT = APP_CONSTANT;
